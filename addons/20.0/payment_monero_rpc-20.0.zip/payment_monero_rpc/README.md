# Monero RPC Payment Module for Odoo 20.0

## Overview

This module provides Monero cryptocurrency payment integration for Odoo 20.0 using direct RPC calls to the Monero daemon and wallet.

This branch targets Odoo 20.0 . It was installed and tested against the real 20.0 source; the POS overlay is not bundled (see ../../../MIGRATION_NOTES.md).

## Key Features

- Full compatibility with Odoo 20.0
- RPC communication with Monero daemon/wallet using Python Monero
- Automated payment verification through scheduled jobs
- Support for multiple wallet addresses as long `payment_ids` (which were used in previous version) are no longer supported
- Seamless integration with Odoo's payment flow

## Technical Migration Details

### Odoo 20.0 Compatibility

This branch carries forward the Odoo 18 rewrite described below, with the 20.0-specific fixes documented in ../../../MIGRATION_NOTES.md applied on top.

### Payment Provider Implementation

The module now implements the `payment.provider` model instead of the deprecated `payment.acquirer` model that was used in versions prior to v15. This change follows Odoo's payment framework evolution and ensures proper integration with the current payment flow system.

### Secondary Address System

The module has moved away from using the long `payment_ids` (which are no longer supported) to using secondary Monero addresses for payment tracking. This architectural change provides better isolation between transactions and improves the reliability of payment matching.

### Automated Payment Verification

The module implements Odoo cron jobs to:

- Periodically check for incoming transactions
- Verify transaction confirmations
- Update payment statuses accordingly
- Reconcile completed payments with orders

This automation ensures payment integrity and reduces manual verification requirements.

## Documentation

Repository-level documents (paths are relative to this file):

- [`../../../README.md`](../../../README.md): layout and status of the 18.0, 19.0 and 20.0 series
- [`../../../MIGRATION_NOTES.md`](../../../MIGRATION_NOTES.md): what changed per version, with evidence
- [`../../../TEST_RESULTS.md`](../../../TEST_RESULTS.md): install and test results
- [`../../../monero_code_review_final.md`](../../../monero_code_review_final.md): runtime security review (19 findings, all fixed)
- [`../../../monero_code_review_three_pass.md`](../../../monero_code_review_three_pass.md): original static audit

## Installation Requirements

- Odoo 20.0
- Access to a Monero wallet RPC instance
- Proper network configuration for RPC communication

## Configuration

After installation, the module can be configured through the Odoo Payment Provider settings:

1. Enable the Monero payment provider
2. Configure Monero RPC connection details
3. Set confirmation thresholds and verification intervals
4. Test the connection to ensure proper communication

## Package reorganization

The 2 modules monero-rpc-odoo and monero-rpc-odoo-pos have been merged into one and following the naming convention for payment modules renamed to payment_monero_rpc.

## Upgrading from Previous Versions

Due to significant changes in both Odoo's payment framework and this module's architecture, a clean installation is recommended when upgrading from versions prior to Odoo 18. Data migration scripts are included but should be tested in a staging environment before use in production.

# Odoo Module Migration Compatibility Table

## Overview of Version Transitions

| Migration Path | Compatibility Level | Major Changes | Development Effort |
|----------------|---------------------|---------------|-------------------|
| 15 → 16        | Moderate           | Architecture changes, View modifications | Medium |
| 16 → 17        | Challenging        | Python requirements, Major UI/UX changes | High |
| 17 → 18        | Moderate           | API changes, New features integration | Medium |
| 15 → 17        | Difficult          | Combined challenges of both migrations | Very High |
| 16 → 18        | Difficult          | Multiple architectural changes | High |
| 15 → 18        | Very Difficult     | Comprehensive rewrite often needed | Very High |

## Detailed Migration Compatibility Table

### Odoo 17 → 18

- **Technical Foundation**:
  - Python 3.11 optimization advantages
  - New database access patterns
  - Enhanced caching mechanisms

## Module Migration Strategy

| Strategy Element | Recommendation |
|------------------|----------------|
| **Assessment** | Conduct thorough code analysis before migration |
| **Database** | Test data migration separately from code updates |
| **Approach** | Consider full rewrites for 15→18 migrations |
| **Testing** | Implement automated tests before migration |
| **Timeline** | Allow 1.5-3x development time compared to original module |
| **Recommended Path** | Migrate one version at a time rather than skipping |
| **Custom Modules** | Consider rebuilding vs migrating for major version jumps |
| **Community Modules** | Check for maintained versions before custom migration |

## Common Migration Issues

1. **Database Schema Conflicts**: Fields renamed or removed between versions
2. **API Deprecations**: Methods removed without direct replacements
3. **UI Component Incompatibility**: View definitions becoming invalid
4. **Report Template Failures**: QWeb reports requiring reconstruction
5. **Security Model Changes**: Access rights and rule modifications
6. **Performance Bottlenecks**: Previously efficient code becoming slow
7. **Third-party Dependencies**: Library compatibility issues

## Best Practices for Migration

1. **Modular Approach**: Migrate core functionality first, then extensions
2. **Testing Framework**: Build comprehensive tests before migration
3. **Version Control**: Use feature branches for migration work
4. **Documentation**: Document all changes and decisions during migration
5. **Incremental Testing**: Test each component after migration
6. **User Training**: Plan for training on new interfaces after migration
7. **Parallel Running**: Consider running old and new systems in parallel initially

### 💰 Donate with Monero (XMR)
88Ae5wwozjnjmhXRN987HXUgNZ8J8MEKBZf8gsxsMHj39HPHjCoirxZFy1UWuNSE36i3AB8ppqMAnNHiskbaut41AqGskaw
<img src="./static/src/img/monero_wallet.png" alt="Monero Wallet" width="300" height="300">
